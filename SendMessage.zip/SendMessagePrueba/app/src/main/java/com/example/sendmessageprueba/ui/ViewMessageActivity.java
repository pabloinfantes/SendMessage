package com.example.sendmessageprueba.ui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import com.example.sendmessageprueba.databinding.ActivityViewMessageBinding;
import com.example.sendmessageprueba.model.Message;

public class ViewMessageActivity extends AppCompatActivity {

    private ActivityViewMessageBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityViewMessageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        Message message = (Message) bundle.getSerializable("message");
        binding.tvUserContent.setText(message.getUser());
        binding.tvMessageContent.setText(message.getMessage());
    }
}